---
name: taste-anti-slop
description: Anti-template design layer for any AI-generated HTML (slides, pages, video frames). Brief inference → dial-driven design → forbidden-pattern filter → pre-flight check. Pairs with html-to-video / claude-design / popular-web-designs.
version: 1.0.0
tags: [design, html, anti-slop, taste, video, slides]
triggers:
  - html-to-video
  - make it look good
  - not AI-generated
  - design taste
  - anti-template
  - avoid slop
related_skills:
  - html-to-video
  - claude-design
  - popular-web-designs
  - article-to-video-production
---

# Taste Anti-Slop — 反模板设计层

> 这不是一个独立的设计技能。这是一个**叠加过滤器**——在任何 AI 生成 HTML 的任务之前加载，确保输出不带有 AI 模板味。
>
> 适用场景：公众号文章转视频幻灯片、Landing Page、演示文稿、产品页面。
> 不适用：Dashboard、数据表格、后台管理系统。

---

## 0. BRIEF INFERENCE（先读懂，再动手）

在写任何代码之前，先输出一行**设计判读**：

**“判读：{内容类型} 面向 {受众}，{风格关键词} 风格，倾向 {设计方向}。”**

示例：
- *“判读：公众号技术文章转视频，面向开发者，冷静克制风格，倾向 Linear-style 暗色 + Geist 字体 + 低动画。”*
- *“判读：品牌故事页面，面向消费者，温暖手工感，倾向 Notion-style 暖色调 + 衬线标题 + 留白。”*
- *“判读：产品 Landing Page，面向企业采购，专业可信风格，倾向 Stripe-style 紫蓝渐变 + 高对比度。”*

**如果需求模糊，只问一个问题，不要多问。** 能推断就推断，不追问。

---

## 1. 三刻度盘

设计判读之后，设三个 1-10 参数。所有布局/配色/动画决策由这三个参数驱动：

- **DESIGN_VARIANCE** (布局变化度)：1=完全对称，10=艺术性不对称
- **MOTION_INTENSITY** (动画强度)：1=静态，10=电影级动画
- **VISUAL_DENSITY** (信息密度)：1=极简留白，10=数据驾驶舱

**默认基线：7 / 4 / 3**（适合大部分文章转视频场景）

| 判读信号 | VARIANCE | MOTION | DENSITY |
|---|---|---|---|
| 极简 / 干净 / 冷静 / Linear-style | 5-6 | 2-3 | 2-3 |
| 品牌 / 高级感 / Apple-y / 奢侈 | 7-8 | 4-6 | 3-4 |
| 活泼 / 创意 / Awwwards / 实验性 | 9-10 | 7-9 | 3-4 |
| Landing / 营销页（默认） | 7-9 | 5-7 | 3-5 |
| 技术文章 / 教程 / 文档 | 5-6 | 2-3 | 4-6 |
| 视频幻灯片（公众号文章转视频） | 6-8 | 3-5 | 3-4 |

---

## 2. 反模板禁令（核心）

以下模式全部禁止，除非内容本身明确需要。

### 2.1 排版禁令

- **❌ Inter 作为默认字体。** 默认用 Geist / Outfit / Satoshi / Cabinet Grotesk。Inter 只在用户明确要求"中性/标准"时可用。
- **❌ 衬线作为默认。** "有创意感=衬线"是 AI 最明显的特征。衬线只在真正编辑/奢侈/出版场景下允许，且禁止 Fraunces 和 Instrument_Serif。
- **❌ em-dash `—` 在任何地方出现。** 标题、正文、注释、按钮、字幕一律禁止。这是 AI 设计的 #1 视觉特征。用句号、逗号、冒号替代。
- **❌ 斜体降部裁剪。** 斜体词含 `y g j p q` 时，行高至少 1.1，底部留 padding。
- **❌ 所有标题都用小型大写 eyebrow。** 每 3 个 section 最多 1 个 eyebrow。

### 2.2 配色禁令

- **❌ AI 紫/蓝光晕。** 禁止自动加紫色按钮发光、霓虹渐变。用中性底色（Zinc/Slate/Stone）+ 单一高对比度强调色。
- **❌ 一张页面两种强调色。** 选定一个强调色，全页统一。暖灰页面不会在第七屏突然出现蓝色 CTA。
- **❌ 对于"高级感消费品牌"自动用 beige+brass+espresso 配色。** 这个组合是 AI 的 #2 视觉特征。换为冷银/深绿/钴蓝+奶油/纯单色+单饱和跳色。
- **❌ `#000000` 纯黑。** 用 off-black（zinc-950 或 charcoal）。

### 2.3 布局禁令

- **❌ 居中 Hero + 渐变背景。** 当 VARIANCE > 4 时，用分屏/左对齐/不对称留白替代。
- **❌ 三列等大功能卡片。** 最明显的 AI 模板特征。用 2 列锯齿、不对称网格、横向滚动替代。
- **❌ 连续 3 屏以上用同一布局模式。** 8 屏页面至少用 4 种不同布局。
- **❌ Hero 区域塞入 tagline + trust strip + 价格提示 + 社交证明。** Hero 最多 4 个文本元素：eyebrow(可选) + 标题 + 副标题(≤20词) + CTA。
- **❌ `<br>` 断行制造"设计感"。** 标题应自然可读，不要用 `<br>` 强制分行。
- **❌ h-screen 全屏 Hero。** 用 `min-h-[100dvh]` 防止移动端地址栏导致跳动。
- **❌ Grid 对齐用 flexbox 百分比数学。** 用 CSS Grid `grid-cols-*`。

### 2.4 内容禁令

- **❌ Jane Doe / John Smith 等通用人名。** 用有地域感、真实感的名字。
- **❌ Acme / Nexus / SmartFlow 等模板品牌名。** 发明有语境感的品牌名。
- **❌ "Elevate"、"Seamless"、"Unleash"、"Next-Gen" 等填充动词。** 用具体动词。
- **❌ 虚假精确数字**（99.99%、4.1×、5.8mm）。除非数据来自真实 brief，否则用自然数。
- **❌ div 拼的假截图/假仪表盘/假终端。** 用真实截图、生成图片、或留占位符。
- **❌ `Trusted by / Quietly in use at` 等模板社交证明标题。** 用自然语言或直接省略。

### 2.5 幻灯片/视频帧专属禁令

- **❌ 每帧都一个布局。** 至少交替 3 种布局：全屏大字 → 分屏图文 → 卡片网格 → 引用大字 → 数据可视化。
- **❌ 标题超过 8 个词。** 视频帧上的标题必须一眼读完。
- **❌ 正文超过 25 个词/帧。** 视频不是阅读器，是视觉传达。
- **❌ 纯色背景 + 居中文字连续 3 帧。** 每帧需要视觉锚点：图片、图标、色块、数据或留白的节奏变化。
- **❌ 视频帧内出现 `<br>` 断行。** 视频帧的文字排版应完整、不依赖换行。
- **❌ emoji 出现在视频文本中。** 用图标库的 SVG icon 替代。

---

## 3. 设计纪律（正面指导）

### 3.1 字体

- 标题：`text-4xl md:text-6xl tracking-tighter leading-none`
- 正文：`text-base text-gray-600 leading-relaxed max-w-[65ch]`
- 推荐无衬线组合：Geist + Geist Mono / Satoshi + JetBrains Mono / Outfit + Inter
- **不要**把衬线字和无衬线字混在同一标题里（如 "and *spatial* design" 的混排套路）。

### 3.2 颜色

- 一个强调色。饱和度 < 80%。
- 中性底色 + 高对比单一强调色（Emerald / Electric Blue / Deep Rose / Burnt Orange）。
- 阴影用背景色调色，不用纯黑投影。
- 同一个项目里暖灰和冷灰不要混用。

### 3.3 布局

- **一张页面一个圆角系统。** 要么全直角(0)、全软角(12-16px)、全胶囊(full)。混用必须有明确规则且全页一致。
- **Hero 顶部间距最大 pt-24。** 超过就是设计 bug，不是"留白感"。
- **导航高度 ≤ 80px。** 桌面端必须单行，折行就是坏设计。
- **用卡片只在需要传达层级时。** 否则用 `border-t` / `divide-y` / 负空间分组。
- **列表项 > 5 个时换 UI 组件。** 不要默认 `<ul>` + `divide-y`，改用 2 列分组 / 卡片网格 / 横向滚动。

### 3.4 图片

优先级：
1. 图片生成工具（如果有）
2. `https://picsum.photos/seed/{描述性种子}/{w}/{h}`
3. 明确标记的占位符 `<!-- TODO: 1600x1200 hero image -->`

**即使是极简页面也需要真实图片。** 纯文本页面不是极简主义，是未完成品。

---

## 4. 幻灯片/视频帧特殊规范

当用于 `html-to-video` 管线时：

- **每帧传达一个想法。** 不要让一帧承载标题+三个要点+数据+引用。
- **标题区 + 内容区明确分离。** 48:52 或 40:60 的垂直分割比居中布局更有力。
- **视频帧需要安全区。** 关键内容放在中心 80% 区域内，边缘留 10% padding。
- **配色考虑视频播放环境。** 手机竖屏 (9:16) 时，暗色背景 + 亮色文字的对比度要求比网页高。
- **字体大小考虑手机观看。** 正文最小 18px（1080px 宽画布），标题最小 36px。
- **帧与帧之间要有视觉节奏。** 满字帧 → 留白帧 → 图文帧 → 大字帧交替。
- **首帧和尾帧特别对待。** 首帧是标题帧（最大字号，最少文字），尾帧是 CTA/二维码帧。
- **进度条/页码放在固定位置。** 所有帧统一位置，不要跳来跳去。

---

## 5. 交付前检查清单

**这不是可选的。每一项必须通过才能输出。**

- [ ] 设计判读已声明（Section 0）？
- [ ] 三刻度盘已设置且从判读推导？
- [ ] **零 em-dash `—`？** 标题、正文、注释、按钮、字幕——全页零出现。
- [ ] 强调色全页统一？没有第七屏换色的情况？
- [ ] 圆角系统全页一致？
- [ ] Hero 没有塞入 tagline + trust strip + 价格 + 社交证明？
- [ ] 没有三列等大功能卡片？
- [ ] 没有 AI 紫/蓝渐变默认配色？
- [ ] Inter 没有作为默认字体？（除非明确要求）
- [ ] 衬线没有作为默认字体？（AI 的 #1 字体特征）
- [ ] 没有 `h-screen`？（用 `min-h-[100dvh]`）
- [ ] 没有 div 拼的假截图？
- [ ] 没有 Jane Doe / Acme / 填充动词？
- [ ] 没有纯黑 `#000000`？
- [ ] 所有 CTA 按钮文字与背景对比度 ≥ WCAG AA（4.5:1）？
- [ ] [视频专属] 每帧一个想法？
- [ ] [视频专属] 标题 ≤ 8 词，正文 ≤ 25 词？
- [ ] [视频专属] 字体大小满足移动端可读？
- [ ] [视频专属] 帧与帧之间有视觉节奏变化？
- [ ] [视频专属] 首帧和尾帧专门设计？

**如果任一项不能诚实打勾，输出未完成。修好再交付。**

---

## 与其他 Skill 的配合

| 任务 | 加载顺序 |
|---|---|
| 公众号文章 → 视频 | `taste-anti-slop` → `html-to-video` |
| 品牌 Landing Page | `taste-anti-slop` → `claude-design` + `popular-web-designs` |
| 产品演示文稿 | `taste-anti-slop` → `reveal-ppt-skill` 或 `guizang-ppt-skill` |
| 文章配图/插图 | `taste-anti-slop` → `baoyu-article-illustrator` |

**规则：taste-anti-slop 总是在其他设计 skill 之前加载。** 它是过滤器，不是替代品。
