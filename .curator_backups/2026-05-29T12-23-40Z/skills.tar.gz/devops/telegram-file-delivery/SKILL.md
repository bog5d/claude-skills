---
name: telegram-file-delivery
description: Send files via Telegram. MEDIA directive limitations and curl fallback for generic document types like HTML, PDF, ZIP, CSV, JSON, YAML, MD
---

# Telegram File Delivery Workflow

## 问题背景

Hermes Agent Telegram 集成支持 `MEDIA:<path>` 发送文件。但底层正则只匹配媒体后缀，通用文档被静默忽略。

## 自带支持的扩展名

- 图片: png, jpg, jpeg, gif, webp
- 视频: mp4, mov, avi, mkv, webm, 3gp
- 音频: ogg, opus, mp3, wav, m4a

**需要 fallback**: pptx, pdf, html, zip, tar.gz, tgz, csv, json, xml, yaml, md

⚠️ PPTX 虽然 PPT 相关但也走 curl fallback，MEDIA 不会发送。

## 方案 A: MEDIA 指令

```
MEDIA:~/Desktop/file.png
```

仅限自带支持的后缀。

## 方案 B: curl Telegram Bot API

**提取 token（注意 strip 空格）：**
```bash
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | head -1 | cut -d= -f2 | tr -d ' ')
```

**三个常用端点：**
```bash
# PPTX/PDF/文档 → sendDocument
curl -s -X POST "https://api.telegram.org/bot${TOKEN}/sendDocument" \
  -F chat_id=<CHAT_ID> \
  -F document=@<FILE_PATH> \
  -F caption="文件描述"

# MP3 音频 → sendAudio（可加 title）
curl -s -X POST "https://api.telegram.org/bot${TOKEN}/sendAudio" \
  -F chat_id=<CHAT_ID> \
  -F audio=@<FILE_PATH> \
  -F title="标题"

# MP4 视频 → sendVideo（可加 supports_streaming）
curl -s -X POST "https://api.telegram.org/bot${TOKEN}/sendVideo" \
  -F chat_id=<CHAT_ID> \
  -F video=@<FILE_PATH> \
  -F supports_streaming=true

# 验证返回值
... | python3 -c "import sys,json; r=json.load(sys.stdin); print('✅' if r.get('ok') else f'❌ {r}')"
```

**Telegram Bot 文件大小限制：50MB。** 超限用 ffmpeg 压缩视频：
```bash
ffmpeg -i input.mp4 -vcodec libx264 -crf 28 -preset fast -acodec aac -b:a 64k output.mp4 -y
```

## 方案 C: 修复正则

修改 `gateway/platforms/base.py` 的 `extract_media()` 中 `media_pattern` 的正则扩展名列表，重启网关。

## 验证

- [ ] 文件路径存在
- [ ] MEDIA 指令的扩展名在白名单中
- [ ] curl fallback 的 token 和 chat_id 正确
