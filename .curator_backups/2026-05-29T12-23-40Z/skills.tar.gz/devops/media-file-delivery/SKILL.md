---
name: media-file-delivery
description: Hermes 文件发送白名单机制。MEDIA 标签只能发送白名单目录下的文件，非白名单路径会导致文件无法投递。此技能记录规则和修复方法，所有 AI 和模型共享。
category: devops
---

# 文件发送白名单机制

## 问题

用 MEDIA 标签发送文件（如 .docx, .pdf）时，Telegram 只显示文件名但没有实际文件内容。

## 根因

Hermes 有一个 `HERMES_MEDIA_ALLOW_DIRS` 环境变量，MEDIA 标签只能发送该白名单目录下的文件。默认白名单（必须用子目录，不能用根目录）：

- `~/.hermes/cache/documents/` — **发 .docx/.pdf 用这个**
- `~/.hermes/cache/images/` — 发图片
- `~/.hermes/cache/audio/` — 发音频
- `~/.hermes/cache/video/` — 发视频
- `~/.hermes/cache/screenshots/` — 发截图

⚠️ 以下路径不在白名单中，发了也收不到：
- `~/.hermes/cache/`（根目录不行）
- `/tmp/`（不在白名单）
- 任何自定义目录

如果文件路径不在白名单中（如 `~/military_ipo/`），MEDIA 标签会被静默忽略，收件人看不到文件。

## 永久修复（四选一，按推荐度排序）

### 方案 A：发送前复制到 /tmp（最简单，无需改配置）
```bash
cp "原文件路径" /tmp/safe_name.docx
# 然后用 /tmp/safe_name.docx 发送
```
优点：不需要改任何配置，任何 AI 都能执行。
缺点：每次需要手动复制。

### 方案 B：设置环境变量（一劳永逸）
在 `~/.hermes/.env` 中添加：
```bash
HERMES_MEDIA_ALLOW_DIRS="/Users/mac/military_ipo:/Users/mac/.hermes/cache/documents:/tmp"
```
然后重启 gateway：
```bash
hermes gateway restart
```
⚠️ .env 受 Hermes credential 保护，需先停 gateway 再改。

### 方案 C：把文件放到默认白名单目录
始终把要发送的文件放到 `~/.hermes/cache/documents/` 或 `/tmp/` 下再发送。

### 方案 D：用 send_message 工具 + 非中文路径
send_message 工具对中文路径支持不稳定，优先用纯 ASCII 路径。

## AI 执行规则

**无论哪个 AI（Hermes/Claude/Cursor/Copilot）、哪个模型、是否重启，发送文件时必须：**

1. 检查文件路径是否在 `/tmp/` 或 `~/.hermes/cache/` 下
2. 如果不在，先 `cp` 到 `/tmp/` 再发送
3. 使用纯 ASCII 文件名（无中文、无空格）
4. 发送后用 `send_message` 工具确认投递成功

## 验证

```bash
# 测试文件是否可发送
cp test.docx /tmp/test_send.docx
# 在回复中使用: MEDIA:/tmp/test_send.docx
```
